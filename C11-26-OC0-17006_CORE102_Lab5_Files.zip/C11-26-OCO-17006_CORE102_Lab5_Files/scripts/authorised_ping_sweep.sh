#!/usr/bin/env bash
set -u

PREFIX="${1:-192.168.56}"
OUT="live_hosts_$(date +%Y%m%d_%H%M%S).txt"
START_TIME=$(date --iso-8601=seconds)

# --- Scope gate: only 192.168.56 is authorised ---
if [[ "$PREFIX" != "192.168.56" ]]; then
    echo "Scope rejected. Authorised prefix: 192.168.56"
    exit 2
fi

echo "Authorised ICMP sweep of ${PREFIX}.0/24" | tee "$OUT"
echo "Start time: $START_TIME" | tee -a "$OUT"

COUNT=0
for host in $(seq 1 254); do
    address="${PREFIX}.${host}"
    if ping -c 1 -w 1 "$address" > /dev/null 2>&1; then
        echo "$address responded" | tee -a "$OUT"
        COUNT=$((COUNT + 1))
    fi
done

FINISH_TIME=$(date --iso-8601=seconds)
echo "Finish time: $FINISH_TIME" | tee -a "$OUT"
echo "Total responsive hosts: $COUNT" | tee -a "$OUT"
echo "Saved: $OUT"
