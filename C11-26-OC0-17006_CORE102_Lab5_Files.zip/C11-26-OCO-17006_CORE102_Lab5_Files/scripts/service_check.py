#!/usr/bin/env python3
import ipaddress
import socket
import sys
from datetime import datetime

AUTHORISED = ipaddress.ip_network('192.168.56.0/24')
PORTS = [22, 53, 80, 443, 8080]

# Optional single-port mode: ./service_check.py HOST [PORT]
if len(sys.argv) not in (2, 3):
    print(f"Usage: {sys.argv[0]} HOST [PORT]")
    raise SystemExit(1)

try:
    target = ipaddress.ip_address(sys.argv[1])
except ValueError:
    print("Invalid IPv4 address")
    raise SystemExit(2)

if target not in AUTHORISED:
    print(f"Scope rejected. Authorised network: {AUTHORISED}")
    raise SystemExit(3)

# If a single port is supplied, validate it
ports_to_check = PORTS
if len(sys.argv) == 3:
    try:
        requested = int(sys.argv[2])
        if not (0 < requested < 65536):
            raise ValueError
        ports_to_check = [requested]
    except ValueError:
        print("Invalid port number")
        raise SystemExit(4)

print(f"CORE102 service check for {target}")
print(f"Started: {datetime.now().isoformat(timespec='seconds')}")

for port in ports_to_check:
    try:
        with socket.create_connection((str(target), port), timeout=1):
            state = "OPEN"
    except (TimeoutError, ConnectionRefusedError, OSError):
        state = "CLOSED OR FILTERED"
    print(f"TCP {port:5}: {state}")
