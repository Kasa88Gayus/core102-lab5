#!/usr/bin/env bash
set -uo pipefail

OUT_DIR="${1:-evidence}"
mkdir -p "$OUT_DIR" || { echo "Cannot create $OUT_DIR"; exit 1; }
OUT_FILE="$OUT_DIR/network_inventory_$(date +%Y%m%d_%H%M%S).txt"

TS=$(date --iso-8601=seconds 2>/dev/null || date +"%Y-%m-%dT%H:%M:%S%z")

section() {
    echo
    echo "================================================"
    echo "  $1"
    echo "================================================"
}

{
    echo "CORE102 NETWORK INVENTORY"
    echo "Generated: $TS"
    echo "Host: $(hostname 2>/dev/null || echo unknown)"
    echo "User: $(whoami 2>/dev/null || echo unknown)"

    section "INTERFACES"
    ip -br link 2>/dev/null || ip link 2>/dev/null || echo "ip link unavailable"
    ip -br addr 2>/dev/null || ip addr 2>/dev/null || echo "ip addr unavailable"

    section "ROUTES"
    ip route 2>/dev/null || echo "ip route unavailable"

    section "DEFAULT GATEWAY AND ROUTE TO LAB SUBNET"
    ip route show default 2>/dev/null || echo "no default route"
    echo
    echo "Route to 192.168.56.1:"
    ip route get 192.168.56.1 2>/dev/null || echo "no route"

    section "NEIGHBOURS"
    ip neigh show 2>/dev/null || echo "ip neigh unavailable"

    section "LISTENING SOCKETS"
    ss -tuln 2>/dev/null || netstat -tuln 2>/dev/null || echo "ss/netstat unavailable"

    section "RESOLVER"
    if [[ -f /etc/resolv.conf ]]; then
        cat /etc/resolv.conf
    else
        echo "/etc/resolv.conf not present"
    fi

    section "DISK SPACE"
    df -h 2>/dev/null || echo "df unavailable"
} > "$OUT_FILE" 2>&1

echo "Inventory saved to $OUT_FILE"
